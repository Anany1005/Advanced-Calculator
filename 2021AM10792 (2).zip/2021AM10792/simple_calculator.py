from stack import Stack

class SimpleCalculator:
	def __init__(self):
		"""
		Instantiate any data attributes
		"""
		self.history = [] # list of tuples (String , result)



	def evaluate_expression(self, input_expression):
		"""
		Evaluate the input expression and return the output as a float
		Return a string "Error" if the expression is invalid
		"""
		n = len(input_expression)
		i = 0
		while(i<n  and input_expression[i]==' '):
			i+=1
		op1 = 0.0
		while(i<n and input_expression[i].isdigit()):
			op1*=10
			op1+=ord(input_expression[i])-ord('0')
			i+=1
		if (i == 0):
			self.history.append((input_expression,"Error"))
			return "Error"
		while(i<n  and input_expression[i]==' '):
			i+=1
		s = input_expression[i]
		i+=1
		while(i<n  and input_expression[i]==' '):
			i+=1
		op2 = 0.0
		while(i<n and input_expression[i].isdigit()):
			op2*=10
			op2+=ord(input_expression[i])-ord('0')
			i+=1
		while(i<n and input_expression[i] == ' '):
			i+=1
		if (i==n):
			if (s == '+'):
				self.history.append((input_expression,op1+op2))
				return op1+op2
			elif (s == '-'):
				self.history.append((input_expression,op1-op2))
				return op1-op2
			elif (s == '*'):
				self.history.append((input_expression,op1*op2))
				return op1*op2
			elif (s == '/'):
				if (op2 == 0):
					self.history.append((input_expression,"Error"))
					return "Error"
				else:
					self.history.append((input_expression,op1/op2))
					return op1/op2
			else:
				return "Error"
		else:
			self.history.append((input_expression,"Error"))
			return "Error"


	def get_history(self):
		"""
		Return history of expressions evaluated as a list of (expression, output) tuples
		The order is such that the most recently evaluated expression appears first 
		"""
		self.history.reverse()
		return self.history