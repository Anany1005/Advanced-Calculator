from simple_calculator import SimpleCalculator
from stack import Stack

class AdvancedCalculator(SimpleCalculator):
	def __init__(self):
		"""
		Call super().__init__()
		Instantiate any additional data attributes
		"""
		self.history = []

	def evaluate_expression(self, input_expression):
		"""
		Evaluate the input expression and return the output as a float
		Return a string "Error" if the expression is invalid
		"""
		x = self.tokenize(input_expression)
		if (x == "Error"):
			self.history.append((input_expression,"Error"))
			return "Error"
		y = self.check_brackets(x)
		if (not y):
			self.history.append((input_expression,"Error"))
			return "Error"
		x = self.evaluate_list_tokens(x)
		if (x == "Error"):
			self.history.append((input_expression,"Error"))
			return "Error"
		self.history.append((input_expression,x))
		return x


	def tokenize(self,s):
		"""
		convert the input string expression to tokens, and return this list
		Each token is either an integer operand or a character operator or bracket
		"""
		l = []
		i = 0
		prev = 0
		n = len(s)
		while i < n:
			if i < n and s[i] == ' ':
				while i < n and s[i] == ' ':
					i += 1
			if i < n and s[i].isdigit():
				op1 = 0
				while i < n and s[i].isdigit():
					op1 *= 10
					op1 += ord(s[i]) - ord('0')
					i += 1
				l.append(op1)
			if i < n and (s[i] == '+' or s[i] == '-' or s[i] == '*' or s[i] == '/' or s[i] == '{' or s[i] == '}' or s[i] == '(' or s[i] == ')'):
				l.append(s[i])
				i += 1
			if prev == i:
				break
			prev = i

		if i == n:
			return l
		return "Error"

	def check_brackets(self, list_tokens):
		"""
		check if brackets are valid, that is, all open brackets are closed by the same type 
		of brackets. Also () contain only () brackets.
		Return True if brackets are valid, False otherwise
		"""
		st = Stack()
		count = 0
		for token in list_tokens:
			if (token == '('):
				count+=1
				st.push(token)
			elif (token == '{'):
				if (count>0):
					return False
				else:
					st.push(token)
			elif (token == '}' or token == ')'):
				if (token == ')'):
					count-=1
				if st.is_empty():
					return False
				top = st.pop()
				if (top=='(' and token!=')'):
					return False
				if (top == '{' and token != '}'):
					return False
		return st.is_empty()

	
	def solve2(self,op1,op2,op):
		if (op == '+'):
			return op1+op2
		if (op == '-'):
			return op1-op2
		if (op =='*'):
			return op1*op2
		if (op =='/'):
			if op2 == 0:
				return "Error"
			return op1/op2
		return "Error"

	def evaluate(self,st):
		print(st)
		st1 = Stack()
		l = []
		prev = 0
		while(not st.is_empty()):
			s = st.pop()
			if s == '/':
				if (prev==0):
					return "Error"
				else:
					c = st.pop()
					st.push(prev/c)
					l.pop()
					prev = 0
			elif (isinstance(s,int) or isinstance(s,float)):
				prev = s
				l.append(s)
			else:
				l.append(s)
		n = len(l)
		print(l)
		l1 = []
		i = 0
		while(i<n):
			if (l[i]=='*'):
				if (i == 0 or i==n-1):
					return "Error"
				qw = l1.pop()
				l1.append(qw*l[i+1])
				i+=1
			else:
				l1.append(l[i])
			i+=1
		n = len(l1)
		l2 = []
		i = 0
		while(i<n):
			if (l1[i]=='+' or l1[i]=='-'):
				if (i == 0 or i==n-1):
					return "Error"
				if (l1[i]=='+'):
					qw=l2.pop()
					l2.append(qw+l1[i+1])
					i+=1
				elif (l1[i]=='-'):
					qw=l2.pop()
					l2.append(qw-l1[i+1])
					i+=1
			else:
				l2.append(l1[i])
			i+=1
		return l2[-1]

	def evaluate_list_tokens(self, list_tokens):
		"""
		Evaluate the expression passed as a list of tokens
		Return the final answer as a float, and "Error" in case of division by zero and other errors
		"""
		st = Stack()
		st1 =Stack()
		for token in list_tokens:
			if (token in ['+','*','-','/','(','{']):
				st.push(token)
			if (isinstance(token,int)):
				st.push(token)
			if (token in [')','}']):
				c = st.pop()
				while(not(c in ['(','}'])):
					st1.push(c)
					if (st.is_empty()):
						return "Error"
					c = st.pop()
				x = self.evaluate(st1)
				st1 = Stack()
				if (x == "Error"):
					return "Error"
				st.push(x)
		st2 = Stack()
		while(not(st.is_empty())):
			s = st.pop()
			st2.push(s)
		return self.evaluate(st2)

		# return "Error"

	def get_history(self):
		"""
		Return history of expressions evaluated as a list of (expression, output) tuples
		The order is such that the most recently evaluated expression appears first 
		"""
		(self.history).reverse()
		return self.history


calculator = AdvancedCalculator()
# tokens = calculator.tokenize("{2 + 3+(2 + 33 + 444 +3)}")
# print(tokens)
# b= calculator.check_brackets(tokens)
# print(b)
# ans =calculator.evaluate_list_tokens(tokens)
ans = calculator.evaluate_list_tokens([3, '-', 4,'/',5])
# print(calculator.tokenize("2 / (43)"))
# print(b)
print(ans)